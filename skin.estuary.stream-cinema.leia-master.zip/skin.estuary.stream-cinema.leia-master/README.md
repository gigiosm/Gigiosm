# skin.estuary.stream-cinema.leia
**Vzhled Estuary Stream-Cinema pro Kodi Leia**

Verze 2.0.27
* doplnena dlazdice CoreELEC do systemovych nastaveni
* oprava cest k doplnku iVysilani - Ceska televize (doplnek instalujte z repozitare XBMC-Kodi CZ/SK)

Verze 2.0.26
* pridana podpora archivu Skylink
* drobné opravy cest

Verze 2.0.25
* oprava cesty k tvnoise.gif pri nedostupnem obrazku (plakatu)

Verze 2.0.24
* oprava chybneho volani pluginu Youtube pokud neni plugin Youtube nainstalovan
* oprava chyby zobrazeni widgetu Posledni sledovane serialy s pouzitim seznamu Trakt

Verze 2.0.23
* opraveny odkazy widgetu "TV dnes" a "TV program na 14 dni"

Verze 2.0.12.a3
* upraveny odkazy widgetů Filmy Stream Cinema

Verze 2.0.12.a2
* opravena chyba zobrazování hodnocení (ratingu)

Verze 2.0.12.a1
* určeno výhradně pro Kodi 18.x Leia
* výchozí verze Estuary 2.0.12
* úprava výchozího vzhledu podle verze Estuary Stream-Cinema 1.9.16.h
* verze je určena k testování nedočkavými uživateli
* určeno výhradně pro Kodi 18.x Leia
